WarpFrac - T4 (sm_75) Cubins
----------------------------
Files:
  - t4_l0_add64_turbo_sm75.cubin
  - t4_l0_mul64_turbo_sm75.cubin
  - t4_l0_add64_turbo_sm75.cubin.sha256
  - t4_l0_mul64_turbo_sm75.cubin.sha256
  - l0_add64_turbo_sm75.cubin
  - l0_mul64_turbo_sm75.cubin
  - l0_add64_turbo_sm75.cubin.sha256
  - l0_mul64_turbo_sm75.cubin.sha256

Notes:
- The files prefixed with 't4_' are human-friendly. The 'compat' names match the loader's expectations.
- If warpfrac is installed, copy any '.cubin' into: python_site_packages/warpfrac/cubin/
- You can verify integrity with:
    sha256sum *.cubin
    cat *.sha256
