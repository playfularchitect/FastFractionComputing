
import cupy as cp
from importlib.resources import files

# We try these filename patterns in this order based on the *current* GPU arch:
_ARCH_MAP = {
    "80": ("sm80","sm_80"),
    "86": ("sm86","sm_86"),
    "75": ("sm75","sm_75"),
}

def _pick_names(base: str) -> list[str]:
    prop = cp.cuda.runtime.getDeviceProperties(cp.cuda.Device().id)
    major, minor = prop["major"], prop["minor"]
    key = f"{major}{minor}"
    patterns = []
    if key in _ARCH_MAP:
        for tag in _ARCH_MAP[key]:
            patterns.append(f"{base}_{tag}.cubin")
    # also add all known tags as fallbacks (in case user compiled only one arch)
    for taglist in _ARCH_MAP.values():
        for tag in taglist:
            cand = f"{base}_{tag}.cubin"
            if cand not in patterns:
                patterns.append(cand)
    return patterns

def _load(base: str, func: str):
    # Try arch-preferred names first, then fallbacks
    for name in _pick_names(base):
        try:
            mod = cp.RawModule(path=str(files("warpfrac.cubin")/name))
            return mod.get_function(func)
        except Exception:
            continue
    raise RuntimeError(f"No .cubin found for {base}. Did you package the binaries?")

def headline_add(N=16_777_216, ITERS=1024, threads=1024, seed=137):
    k = _load("l0_add64_turbo", "l0_add64_turbo")
    rng = cp.random.default_rng(seed)
    exp_choices = cp.arange(-16, 17, dtype=cp.int32)
    a_num = rng.integers(-2**30, 2**30, size=N, dtype=cp.int64)
    b_num = rng.integers(-2**30, 2**30, size=N, dtype=cp.int64)
    a_exp = exp_choices[rng.integers(0, exp_choices.size, size=N, dtype=cp.int32)]
    b_exp = exp_choices[rng.integers(0, exp_choices.size, size=N, dtype=cp.int32)]
    outn = cp.empty_like(a_num); oute = cp.empty_like(a_exp)
    blocks = (N + threads - 1)//threads
    ev0=cp.cuda.Event(); ev1=cp.cuda.Event()
    ev0.record()
    k((blocks,), (threads,), (a_num,a_exp,b_num,b_exp,outn,oute,cp.int32(ITERS),cp.int32(N)))
    cp.cuda.Device().synchronize(); ev1.record(); ev1.synchronize()
    dt = cp.cuda.get_elapsed_time(ev0, ev1)/1000.0
    return {"name":"headline_add","ops":int(N*ITERS),"sec":float(dt),
            "gops":float(N*ITERS/dt/1e9),"tops":float(N*ITERS/dt/1e12)}

def headline_mul(N=16_777_216, ITERS=1024, threads=1024, seed=123):
    k = _load("l0_mul64_turbo", "l0_mul64_turbo")
    rng = cp.random.default_rng(seed)
    a_num = rng.integers(-2**20, 2**20, size=N, dtype=cp.int64)
    b_num = rng.integers(-2**20, 2**20, size=N, dtype=cp.int64)
    a_exp = rng.integers(-16, 17, size=N, dtype=cp.int32)
    b_exp = rng.integers(-16, 17, size=N, dtype=cp.int32)
    outn = cp.empty_like(a_num); oute = cp.empty_like(a_exp)
    blocks = (N + threads - 1)//threads
    ev0=cp.cuda.Event(); ev1=cp.cuda.Event()
    ev0.record()
    k((blocks,), (threads,), (a_num,a_exp,b_num,b_exp,outn,oute,cp.int32(ITERS),cp.int32(N)))
    cp.cuda.Device().synchronize(); ev1.record(); ev1.synchronize()
    dt = cp.cuda.get_elapsed_time(ev0, ev1)/1000.0
    return {"name":"headline_mul","ops":int(N*ITERS),"sec":float(dt),
            "gops":float(N*ITERS/dt/1e9),"tops":float(N*ITERS/dt/1e12)}

def _fmt(d):
    return f"{d['name']:<14} | ops={d['ops']:,} | sec={d['sec']:.6f} | gops={d['gops']:.3f} | tops={d['tops']:.3f}"

def main():
    try:
        a = headline_add()
        m = headline_mul()
        print("warpfrac-demo")
        print(_fmt(a))
        print(_fmt(m))
    except Exception as e:
        print("warpfrac-demo error:", e)
