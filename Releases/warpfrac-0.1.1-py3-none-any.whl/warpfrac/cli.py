import argparse, sys, json
from . import add, sub, mul, div, cmp, reduce

def parse_frac(s: str):
    # accepts 'p/q' or integer 'p' (=> p/1)
    if '/' in s:
        p,q = s.split('/',1)
        return (int(p.strip()), int(q.strip()))
    return (int(s.strip()), 1)

def main():
    p = argparse.ArgumentParser(prog="warpfrac", description="warpfrac public API CLI")
    sub = p.add_subparsers(dest="cmd", required=True)

    for name in ["add","sub","mul","div","cmp"]:
        sp = sub.add_parser(name)
        sp.add_argument("x"); sp.add_argument("y")

    sr = sub.add_parser("reduce")
    sr.add_argument("x")

    args = p.parse_args()
    try:
        if args.cmd == "reduce":
            x = parse_frac(args.x)
            print(json.dumps(reduce(x)))
            return
        x = parse_frac(args.x); y = parse_frac(args.y)
        if args.cmd == "add": print(json.dumps(add(x,y))); return
        if args.cmd == "sub": print(json.dumps(sub(x,y))); return
        if args.cmd == "mul": print(json.dumps(mul(x,y))); return
        if args.cmd == "div": print(json.dumps(div(x,y))); return
        if args.cmd == "cmp": print(json.dumps(cmp(x,y))); return
    except Exception as e:
        print(json.dumps({"ok": False, "error": str(e)}))
        sys.exit(1)

if __name__ == "__main__":
    main()
