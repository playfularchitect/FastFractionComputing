from typing import Tuple
import math

Frac = Tuple[int, int]

def _norm(n: int, d: int) -> Frac:
    if d == 0:
        raise ZeroDivisionError("denominator cannot be zero")
    # keep denominator > 0, push sign to numerator
    if d < 0:
        n, d = -n, -d
    g = math.gcd(n, d)
    if g:
        n //= g
        d //= g
    return (n, d)

def reduce(x: Frac) -> Frac:
    n, d = x
    return _norm(int(n), int(d))

def add(a: Frac, b: Frac) -> Frac:
    an, ad = a; bn, bd = b
    return _norm(an*bd + bn*ad, ad*bd)

def sub(a: Frac, b: Frac) -> Frac:
    an, ad = a; bn, bd = b
    return _norm(an*bd - bn*ad, ad*bd)

def mul(a: Frac, b: Frac) -> Frac:
    an, ad = a; bn, bd = b
    return _norm(an*bn, ad*bd)

def div(a: Frac, b: Frac) -> Frac:
    an, ad = a; bn, bd = b
    if bn == 0:
        raise ZeroDivisionError("division by zero fraction")
    return _norm(an*bd, ad*bn)

def cmp(a: Frac, b: Frac) -> int:
    an, ad = _norm(a[0], a[1])
    bn, bd = _norm(b[0], b[1])
    lhs = an * bd
    rhs = bn * ad
    if lhs < rhs: return -1
    if lhs > rhs: return 1
    return 0
