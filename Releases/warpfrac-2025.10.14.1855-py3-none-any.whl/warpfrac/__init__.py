from ._loader import headline_add, headline_mul
__all__=['headline_add','headline_mul']
