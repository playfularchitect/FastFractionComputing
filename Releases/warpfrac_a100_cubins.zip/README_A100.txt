WarpFrac - A100 (sm_80) Cubins
------------------------------
Files:
  - a100_l0_add64_turbo_sm80.cubin
  - a100_l0_mul64_turbo_sm80.cubin
  - a100_l0_add64_turbo_sm80.cubin.sha256
  - a100_l0_mul64_turbo_sm80.cubin.sha256
  - l0_add64_turbo_sm80.cubin
  - l0_mul64_turbo_sm80.cubin
  - l0_add64_turbo_sm80.cubin.sha256
  - l0_mul64_turbo_sm80.cubin.sha256

Notes:
- The files prefixed with 'a100_' are human-friendly. The 'compat' names match the loader's expectations.
- If warpfrac is installed, copy any '.cubin' into: python_site_packages/warpfrac/cubin/
- Verify integrity with:
    sha256sum *.cubin
    cat *.sha256
